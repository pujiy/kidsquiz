package com.nuraffchaniago.kidsquiz;

public class URLs {

    private static final String ROOT_URL = "http://kidlearns.online/public/";

    public static final String URL_REGISTER = ROOT_URL + "register";
    public static final String URL_LOGIN = ROOT_URL + "login";
    public static final String URL_LEADERBOARD = ROOT_URL + "usersleaderboard";
    public static final String URL_UPDATESCORE = ROOT_URL + "updatescore";

}
