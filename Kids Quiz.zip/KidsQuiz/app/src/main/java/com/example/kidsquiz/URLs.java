package com.example.kidsquiz;

public class URLs {

    private static final String ROOT_URL = "http://pujiymobileapp.online/public/";

    public static final String URL_REGISTER = ROOT_URL + "register";
    public static final String URL_LOGIN = ROOT_URL + "login";
}
